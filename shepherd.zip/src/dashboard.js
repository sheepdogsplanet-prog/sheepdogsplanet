import { supabase } from "./supabase.js";

const userEmailSpan = document.getElementById("user-email");
const badge = document.getElementById("membership-badge");
const freeContent = document.getElementById("free-content");
const premiumContent = document.getElementById("premium-content");
const logoutBtn = document.getElementById("logout-btn");

async function checkUser() {
  // 1. Otteniamo l'utente sessione attuale
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    // Se non c'è sessione, torna al login (sicurezza)
    window.location.href = "index.html";
    return;
  }

  userEmailSpan.textContent = user.email;

  // 2. Leggiamo il profilo dalla tabella pubblica (creata dal tuo trigger SQL)
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("membership")
    .eq("id", user.id)
    .single();

  if (profileError) {
    console.error("Errore caricamento profilo:", profileError);
    return;
  }

  // 3. Logica del tuo schema: Free or Premium?
  if (profile.membership === "premium") {
    badge.textContent = "PREMIUM";
    badge.style.backgroundColor = "#ffd700"; // Oro
    badge.style.color = "black";
    premiumContent.classList.remove("hidden");
  } else {
    badge.textContent = "FREE";
    badge.style.backgroundColor = "#e0e0e0"; // Grigio
    freeContent.classList.remove("hidden");
  }
}

// Gestione Logout
logoutBtn.addEventListener("click", async () => {
  await supabase.auth.signOut();
  window.location.href = "index.html";
});

// Avvia il controllo al caricamento della pagina
checkUser();
