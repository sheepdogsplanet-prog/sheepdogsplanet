import { supabase } from "./supabase.js";

const emailForm = document.getElementById("email-form");

emailForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  localStorage.setItem("userEmail", email);

  // 1. Controlliamo se l'utente esiste già
  const { data: profile } = await supabase
    .from("profiles")
    .select("email")
    .eq("email", email)
    .single();

  if (profile) {
    // UTENTE ESISTE: Vai alla password (Linea Verde)
    window.location.href = "password.html";
  } else {
    // NUOVO UTENTE (Linea Rossa): Registrazione iniziale
    // Usiamo signUp con una password temporanea o casuale
    // Supabase invierà l'email di conferma/benvenuto
    const { error: signUpError } = await supabase.auth.signUp({
      email: email,
      password: "password_temporanea_123", // Verrà cambiata nel reset
      options: {
        emailRedirectTo: window.location.origin + "/reset.html",
      },
    });

    if (signUpError) {
      alert("Errore registrazione: " + signUpError.message);
    } else {
      alert("Benvenuto! Controlla la tua email per impostare la password.");
    }
  }
});
