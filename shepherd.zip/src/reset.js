import { supabase } from "./supabase.js";

const resetForm = document.getElementById("reset-form");

resetForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const newPassword = document.getElementById("new-password").value;

  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  });

  if (error) {
    alert("Errore durante il reset: " + error.message);
  } else {
    alert("Password impostata! Ora puoi accedere.");
    window.location.href = "dashboard.html";
  }
});
