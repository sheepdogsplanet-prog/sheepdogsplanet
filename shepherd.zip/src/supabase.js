import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const supabaseUrl = "https://qmjmwxckglypginobvol.supabase.co";
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFtam13eGNrZ2x5cGdpbm9idm9sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAyMTIwMjMsImV4cCI6MjA4NTc4ODAyM30.qwilEC8aizc5F4tyAQlMpuW9PBE3eTkDuB0Y-0YcYfw";

export const supabase = createClient(supabaseUrl, supabaseKey);
