import { supabase } from "./supabase.js";

const passwordForm = document.getElementById("password-form");
const passwordInput = document.getElementById("password");
const emailDisplay = document.getElementById("user-email-display");
const forgotLink = document.getElementById("forgot-password");
const messageDiv = document.getElementById("message");

// Recuperiamo l'email salvata nella pagina precedente
const userEmail = localStorage.getItem("user-email");

if (!userEmail) {
  window.location.href = "index.html"; // Se non c'è l'email, torna indietro
} else {
  emailDisplay.textContent = `Accedi come: ${userEmail}`;
}

// --- LOGICA LOGIN (Freccia Verde) ---
passwordForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const password = passwordInput.value;

  const { data, error } = await supabase.auth.signInWithPassword({
    email: userEmail,
    password: password,
  });

  if (error) {
    // Se l'utente non esiste, proviamo a registrarlo (Linea rossa "new user")
    if (error.message.includes("Invalid login credentials")) {
      messageDiv.textContent = "Credenziali errate o utente non registrato.";
      // Opzionale: potresti chiamare supabase.auth.signUp qui se vuoi registrarlo al volo
    } else {
      messageDiv.textContent = error.message;
    }
  } else {
    // Successo! Vai alla dashboard
    window.location.href = "dashboard.html";
  }
});

// --- LOGICA PASSWORD DIMENTICATA (Freccia Rossa Centrale) ---
forgotLink.addEventListener("click", async (e) => {
  e.preventDefault();

  const { error } = await supabase.auth.resetPasswordForEmail(userEmail, {
    // L'URL deve corrispondere a dove hai caricato reset.html su CodeSandbox
    redirectTo: window.location.origin + "/reset.html",
  });

  if (error) {
    messageDiv.textContent = "Errore invio email: " + error.message;
  } else {
    messageDiv.style.color = "green";
    messageDiv.textContent = "Email di reset inviata! Controlla la tua posta.";
  }
});
